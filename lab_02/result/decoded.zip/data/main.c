#include <stdio.h>

int main(void) {
    printf("Программа для шифрования!\n");

    return 0;
}
